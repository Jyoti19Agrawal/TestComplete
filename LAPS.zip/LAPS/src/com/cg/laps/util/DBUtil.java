package com.cg.laps.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.laps.exception.LoanException;

public class DBUtil {

	public static Connection getConnection() throws LoanException {
		Connection con = null;
		Properties prop = new Properties();
		try {
			FileReader fr = new FileReader("resources/jdbc.properties");
			prop.load(fr);
			String url = prop.getProperty("jdbcurl");
			String user = prop.getProperty("jdbcuser");
			String pass = prop.getProperty("jdbcpass");
			con = DriverManager.getConnection(url, user, pass);
		} catch (FileNotFoundException e) {
			throw new LoanException("jdbc.properties file not found");

		} catch (IOException e) {
			throw new LoanException("Unable to read properties file");
		} catch (SQLException e) {
			throw new LoanException("Unable to connect to database");
		}

		return (con);

	}
}
