package com.cg.laps.test;

import java.time.LocalDate;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.laps.dao.LoanDAO;
import com.cg.laps.dao.LoanDAOImpl;
import com.cg.laps.dto.CustomerDetails;
import com.cg.laps.dto.LoanApplication;
import com.cg.laps.dto.LoanProgramsOffered;
import com.cg.laps.exception.LoanException;

public class LoanDAOTest {

	static LoanDAO dao;
	static CustomerDetails customer;
	static LoanApplication loan;
	static LoanProgramsOffered programs;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new LoanDAOImpl();
		customer = new CustomerDetails();
		loan = new LoanApplication();
		programs = new LoanProgramsOffered();
	}

	/************************************
	 * Test case for addCustomerDetails()
	 * 
	 ************************************/
	 
	 
	@Test
	public void testAddCustomerDetails() throws LoanException {
		LocalDate newDate = LocalDate.of(1999, 12, 11);
		customer.setApplicantName("Himanshu Kemwal");
		customer.setDob(newDate);
		customer.setCountOfDepandants(5);
		customer.setEmailId("abc@gmail.com");
		customer.setMaritalStatus("Single");
		customer.setMobileNumber(9874563210L);
		customer.setPhoneNumber(89652310L);
		int id =dao.addCustomerDetails(customer);
		assertTrue(true);

	}

	/************************************
	 * Test case for addLoanApplicationDetails()
	 * 
	***********************************/
	@Test
	public void testAddLoanApplicationDetails() throws LoanException {
		LocalDate newDate = LocalDate.of(2017, 12, 22);
		LocalDate newDate1 = LocalDate.of(2017, 12, 25);
		loan.setLoanProgram("HL01");
		loan.setApplicationId(1073);
		loan.setAddressOfProperty("Bangalore");
		loan.setAmountOfLoan(100000.0f);
		loan.setAnnualFamilyIncome(150000.0f);
		loan.setDocumentProofs("Aadhar Card");
		loan.setApplicationDate(newDate); 
		loan.setStatus("APPLIED");
		loan.setDateOfInterview(newDate1);
		int id = dao.addLoanApplicationDetails(loan);
		assertNotNull(id);
		}


	/********************************************
	 * Test case for viewLoanProgramsOffered()
	 ************************************************/
	@Test
	public void testviewLoanProgramsOffered() throws LoanException {
		assertNotNull(dao.viewLoanProgramsOffered());
	}

	/****************************************************
	 * Test case for viewLoanById()
	 ******************************************************/

	@Test
	public void testViewLoanById() throws LoanException {
		assertNotNull(dao.viewLoanById(1073));
	}

	/****************************************************
	 * Test case for viewCustomerById()
	 ******************************************************/

	 @Test
	public void testViewCustomerById() throws LoanException {
		assertNotNull(dao.viewCustomerById(1073));
	}

	/****************************************************
	 * Test case for loginService()
	 ******************************************************/
	  
	 @Test
	public void testLoginService() throws LoanException {
		assertNotNull(dao.loginService("lad", "lad123", "Lad"));
	}

	/****************************************************
	 * Test case for viewApplicationsByName()
	 ******************************************************/

	 @Test
	public void testViewApplicationsByName() throws LoanException {
		assertNotNull(dao.viewApplicationsByName("HL01"));
	}

	/****************************************************
	 * Test case for updateStatus()
	 ******************************************************/

	 @Test
	public void testUpdateStatus() throws LoanException {
		assertNotNull(dao.updateStatus(1073, "ACCEPTED"));
	}

}
